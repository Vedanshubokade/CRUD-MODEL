<?php

namespace Tqdev\PhpCrudApi\Cache;

use Tqdev\PhpCrudApi\Cache\Base\BaseCache;

class NoCache extends BaseCache implements Cache
{
}
